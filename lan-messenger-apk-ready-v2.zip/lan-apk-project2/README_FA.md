# APK آماده LAN Messenger

این پروژه یک Android WebView Wrapper برای همان مسنجر تحت شبکه محلی است. خود پروژه وب و دیتابیس روی AWebServer می‌مانند؛ APK فقط به آن متصل می‌شود.

## قابلیت‌ها
- آدرس پیش‌فرض: `http://192.168.1.9:8080/`
- ذخیره آخرین IP و Port
- تغییر IP/Port در صورت تغییر سرور
- اجازه Microphone برای `getUserMedia()` و ضبط صدا
- اجازه Camera در صورت نیاز
- File Picker واقعی اندروید برای `input type=file`
- انتخاب چند فایل
- دانلود فایل‌ها
- JavaScript / LocalStorage / Cookies
- HTTP شبکه محلی (Cleartext)
- Back گوشی: اگر WebView تاریخچه داشته باشد یک مرحله برمی‌گردد؛ در غیر این صورت فرم اتصال را نشان می‌دهد.

## ساخت با گوشی و GitHub
1. کل محتویات این پوشه را در ریشه Repository گیت‌هاب قرار بده.
2. فایل `.github/workflows/build-apk.yml` باید دقیقاً وجود داشته باشد.
3. GitHub → Actions → `Build LAN Messenger APK` → `Run workflow`.
4. بعد از سبز شدن Build، از بخش Artifacts فایل `LAN-Messenger-debug-apk` را دانلود کن.
5. ZIP آرتیفکت را باز کن و `app-debug.apk` را روی گوشی نصب کن.

## نکته
این APK نباید فایل‌های PHP/JS پروژه را داخل خودش کپی کند. پروژه اصلی باید همچنان روی AWebServer باشد و APK به URL آن وصل شود.
