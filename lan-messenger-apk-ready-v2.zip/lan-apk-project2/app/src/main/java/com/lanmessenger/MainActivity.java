package com.lanmessenger;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.webkit.*;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private View connectView;
    private EditText host, port;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private final Handler handler = new Handler();
    private Runnable timeoutRunnable;
    private boolean loadingServer = false;
    private String currentUrl = "";

    private static final String PREFS = "lan_messenger";
    private static final String HOST = "host";
    private static final String PORT = "port";
    private static final String DEFAULT_HOST = "192.168.1.9";
    private static final String DEFAULT_PORT = "8080";
    private static final int REQ_MEDIA = 101;
    private static final int REQ_FILES = 102;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setContentView(R.layout.activity_main);
        connectView = findViewById(R.id.connectPanel);
        host = findViewById(R.id.host);
        port = findViewById(R.id.port);
        host.setText(prefs.getString(HOST, DEFAULT_HOST));
        port.setText(prefs.getString(PORT, DEFAULT_PORT));
        connectView.setOnClickListener(v -> connectFromForm());
        setupWebView();
        trySavedServer();
    }

    private void setupWebView() {
        web = new WebView(this);
        addContentView(web, new ViewGroup.LayoutParams(-1, -1));
        web.setVisibility(View.GONE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportZoom(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap favicon) {
                loadingServer = true;
                if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (loadingServer) {
                    loadingServer = false;
                    handler.removeCallbacks(timeoutRunnable);
                    currentUrl = url;
                    web.setVisibility(View.VISIBLE);
                    connectView.setVisibility(View.GONE);
                }
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showConnect("اتصال به سرور برقرار نشد. IP و پورت را بررسی کنید.");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return false;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(params.getAcceptTypes() != null && params.getAcceptTypes().length > 0 && !params.getAcceptTypes()[0].isEmpty() ? params.getAcceptTypes()[0] : "*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(i, REQ_FILES); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch (Exception ignored) { }
        });
    }

    private void handleWebPermission(PermissionRequest request) {
        pendingWebPermission = request;
        boolean mic = false, cam = false;
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true;
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
        }
        ArrayList<String> needs = new ArrayList<>();
        if (mic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needs.add(Manifest.permission.RECORD_AUDIO);
        if (cam && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needs.add(Manifest.permission.CAMERA);
        if (needs.isEmpty()) { grantWebResources(request); return; }
        requestPermissions(needs.toArray(new String[0]), REQ_MEDIA);
    }

    private void grantWebResources(PermissionRequest request) {
        ArrayList<String> allowed = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) allowed.add(r);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) allowed.add(r);
        }
        if (!allowed.isEmpty()) request.grant(allowed.toArray(new String[0])); else request.deny();
        pendingWebPermission = null;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MEDIA && pendingWebPermission != null) grantWebResources(pendingWebPermission);
    }

    private void trySavedServer() {
        String h = prefs.getString(HOST, DEFAULT_HOST), p = prefs.getString(PORT, DEFAULT_PORT);
        host.setText(h); port.setText(p);
        connect(h, p);
    }

    private void connectFromForm() { connect(host.getText().toString(), port.getText().toString()); }

    private void connect(String h, String p) {
        h = h.trim().replaceFirst("^https?://", "").replaceAll("/.*$", "");
        p = p.trim();
        if (h.isEmpty() || p.isEmpty()) { showConnect("آدرس سرور و پورت را وارد کنید."); return; }
        try { int n = Integer.parseInt(p); if (n < 1 || n > 65535) throw new Exception(); } catch(Exception e) { showConnect("شماره پورت معتبر نیست."); return; }
        final String url = "http://" + h + ":" + p + "/";
        prefs.edit().putString(HOST,h).putString(PORT,p).apply();
        loadingServer = true;
        currentUrl = url;
        web.setVisibility(View.VISIBLE);
        connectView.setVisibility(View.GONE);
        web.loadUrl(url);
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
        timeoutRunnable = () -> { if (loadingServer) { loadingServer=false; web.stopLoading(); showConnect("سرور پیدا نشد یا در دسترس نیست."); } };
        handler.postDelayed(timeoutRunnable, 8000);
    }

    private void showConnect(String message) {
        loadingServer = false;
        web.stopLoading();
        web.setVisibility(View.GONE);
        connectView.setVisibility(View.VISIBLE);
        TextView info = findViewById(R.id.info);
        if (info != null) info.setText(message);
    }

    @Override public void onBackPressed() {
        if (web.getVisibility() == View.VISIBLE && web.canGoBack()) { web.goBack(); return; }
        if (web.getVisibility() == View.VISIBLE) { showConnect("برای تغییر سرور، آدرس را وارد کنید."); return; }
        super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n=data.getClipData().getItemCount(); results=new Uri[n];
                    for(int i=0;i<n;i++) results[i]=data.getClipData().getItemAt(i).getUri();
                } else if (data.getData()!=null) results=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results); fileCallback=null;
        }
    }
}
